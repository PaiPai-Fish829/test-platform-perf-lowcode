<template>
  <div class="dashboard-app">
    <header class="glass-header">
      <div class="header-left">
        <div class="logo-area">
          <svg fill="#15803d" width="28" height="28" viewBox="0 0 24 24">
            <path
              d="M12 2L2 7v10l10 5 10-5V7l-10-5zM10 19.76l-6-3V8.24l6 3v8.52zm8-3l-6 3v-8.52l6-3v8.52zM12 11.24L6.24 8.5 12 5.76l5.76 2.74L12 11.24z"></path>
          </svg>
          <span class="logo-text"> 压测监控平台</span>
        </div>
        <ElMenu
          mode="horizontal"
          class="nav-menu"
          text-color="#15803d"
          :default-active="state.activeMenu"
          background-color="transparent"
          active-text-color="#15803d"
          @select="handleMenuSelect">
          <ElMenuItem index="task"> 测试任务</ElMenuItem>
          <ElMenuItem index="report"> 测试报告</ElMenuItem>
          <ElMenuItem index="dashboard"> 仪表盘</ElMenuItem>
          <ElSubMenu index="resources">
            <template #title="scope_3bbkdq31ua">
              <span> 测试资源</span>
            </template>
            <ElMenuItem index="script"> 脚本库</ElMenuItem>
            <ElMenuItem index="strategy"> 策略库</ElMenuItem></ElSubMenu
          ></ElMenu
        >
      </div>
      <div class="header-right">
        <div class="status-badge">
          <span class="status-dot"></span>
          <span class="status-label"> 空闲</span>
        </div>
        <ElButton
          icon="CircleClose"
          size="small"
          type="danger"
          class="stop-btn"
          round="">
          停止运行</ElButton
        >
      </div>
    </header>
    <main v-if="state.activeMenu === 'task'" class="main-content">
      <TestTaskPanel></TestTaskPanel>
    </main>
    <main v-else-if="state.activeMenu === 'dashboard'" class="main-content">
      <div class="kpi-row">
        <div class="glass-card kpi-card">
          <div class="kpi-header">
            <span class="kpi-label"> 当前 RPS</span>
            <span class="kpi-trend up"> ↑ 12%</span>
          </div>
          <div class="kpi-value">342</div>
          <div class="kpi-sub">
            <span> 峰值</span>
            <span class="highlight"> 1,234</span>
          </div>
        </div>
        <div class="glass-card kpi-card">
          <div class="kpi-header">
            <span class="kpi-label"> 失败率</span>
            <span class="kpi-trend down"> ↑ 0.05%</span>
          </div>
          <div class="kpi-value error">0.23%</div>
          <div class="kpi-sub">
            <span> 成功率</span>
            <span class="highlight"> 99.77%</span>
          </div>
        </div>
        <div class="glass-card kpi-card">
          <div class="kpi-header">
            <span class="kpi-label"> P95 响应时间</span>
          </div>
          <div class="kpi-value">156ms</div>
          <div class="kpi-sub">
            <span> 阈值</span>
            <span class="highlight"> 500ms</span>
          </div>
        </div>
        <div class="glass-card kpi-card">
          <div class="kpi-header">
            <span class="kpi-label"> 活跃用户数</span>
            <span class="kpi-trend up"> ↑ 8%</span>
          </div>
          <div class="kpi-value">45</div>
          <div class="kpi-sub">
            <span> 峰值</span>
            <span class="highlight"> 67</span>
          </div>
        </div>
      </div>
      <div class="glass-card chart-section">
        <h3 class="chart-title">每秒请求数 (RPS)</h3>
        <XChart width="100%" height="260px" :option="state.rpsOption"></XChart>
      </div>
      <div class="glass-card chart-section">
        <h3 class="chart-title">响应时间 (ms)</h3>
        <XChart
          width="100%"
          height="260px"
          :option="state.responseTimeOption"></XChart>
      </div>
      <div class="glass-card chart-section">
        <h3 class="chart-title">活跃用户数趋势</h3>
        <XChart
          width="100%"
          height="260px"
          :option="state.activeUsersOption"></XChart>
      </div>
      <div class="glass-card table-section">
        <h3 class="section-title">详细 API 统计</h3>
        <ElTable
          :data="state.apiStats"
          size="small"
          class="api-table ElTable_3bzkdq31ul"
          :style="{ width: '100%' }"
          border=""
          max-height="300">
          <ElTableColumn
            prop="type"
            fixed=""
            label="Type"
            width="100"></ElTableColumn>
          <ElTableColumn prop="name" label="Name" width="180"></ElTableColumn>
          <ElTableColumn
            prop="requests"
            label="#Requests"
            width="100"></ElTableColumn>
          <ElTableColumn prop="fails" label="#Fails" width="90">
            <template #default="scope">
              <span :class="{ 'fails-highlight': scope.row.fails > 0 }">
                {{ scope.row.fails }}</span
              >
            </template></ElTableColumn
          >
          <ElTableColumn
            prop="median"
            label="Median(ms)"
            width="110"></ElTableColumn>
          <ElTableColumn prop="p95" label="95%ile(ms)" width="110">
            <template #default="scope">
              <span :class="{ 'p95-highlight': scope.row.p95 > 500 }">
                <span> {{ scope.row.p95 }}</span>
                <span v-if="scope.row.p95 > 500" class="flame-icon">
                  🔥</span
                ></span
              >
            </template></ElTableColumn
          >
          <ElTableColumn
            prop="p99"
            label="99%ile(ms)"
            width="110"></ElTableColumn>
          <ElTableColumn
            prop="avg"
            label="Average(ms)"
            width="110"></ElTableColumn>
          <ElTableColumn prop="min" label="Min(ms)" width="100"></ElTableColumn>
          <ElTableColumn prop="max" label="Max(ms)" width="100"></ElTableColumn>
          <ElTableColumn
            prop="avgSize"
            label="Avg Size(bytes)"
            width="130"></ElTableColumn>
          <ElTableColumn
            prop="currentRps"
            label="Current RPS"
            width="110"></ElTableColumn>
          <ElTableColumn
            prop="currentFails"
            label="Current Fails/s"
            width="130"></ElTableColumn
        ></ElTable>
      </div>
      <div class="table-row">
        <div class="glass-card table-half left">
          <h3 class="section-title">失败请求明细</h3>
          <ElTable
            :data="state.failDetails"
            size="small"
            :style="{ width: '100%' }"
            border=""
            max-height="250"
            class="ElTable_3cmkdq31um">
            <ElTableColumn
              prop="failCount"
              label="失败数"
              width="80"></ElTableColumn>
            <ElTableColumn
              prop="method"
              label="方法"
              width="70"></ElTableColumn>
            <ElTableColumn
              prop="apiName"
              label="接口名"
              width="150"></ElTableColumn>
            <ElTableColumn
              prop="errorInfo"
              label="错误信息"
              width="200"
              show-overflow-tooltip=""></ElTableColumn>
            <ElTableColumn
              prop="firstSeen"
              label="首次出现"
              width="160"></ElTableColumn>
            <ElTableColumn
              prop="lastSeen"
              label="最后出现"
              width="160"></ElTableColumn
          ></ElTable>
        </div>
        <div class="glass-card table-half right">
          <h3 class="section-title">异常统计</h3>
          <ElTable
            :data="state.exceptionStats"
            size="small"
            :style="{ width: '100%' }"
            border=""
            max-height="250"
            class="ElTable_3cvkdq31um">
            <ElTableColumn
              prop="count"
              label="发生次数"
              width="90"></ElTableColumn>
            <ElTableColumn
              prop="exceptionInfo"
              label="异常信息"
              width="250"
              show-overflow-tooltip=""></ElTableColumn>
            <ElTableColumn
              prop="stackSummary"
              label="堆栈摘要"
              width="250"
              show-overflow-tooltip=""></ElTableColumn
          ></ElTable>
        </div>
      </div>
      <div class="glass-card toolbar">
        <div class="log-preview">
          <span
            v-for="(log, idx) in state.recentLogs"
            :key="idx"
            class="log-item">
            <ElTag size="small" :type="log.level" effect="plain">
              {{ log.level }}</ElTag
            >
            <span class="log-msg"> {{ log.msg }}</span></span
          >
        </div>
        <div class="success-rate">
          <span class="rate-label"> 成功率</span>
          <ElProgress
            color="#15803d"
            striped=""
            :percentage="99.77"
            :stroke-width="12"></ElProgress>
        </div>
        <ElButton
          icon="Download"
          size="default"
          type="primary"
          :style="{ 'background-color': '#15803d', 'border-color': '#15803d' }"
          class="ElButton_3d7kdq31up">
          导出数据</ElButton
        >
      </div>
    </main>
    <main v-else class="main-content placeholder-page">
      <div class="glass-card placeholder-card">
        <svg
          fill="#15803d"
          width="64"
          height="64"
          opacity="0.3"
          viewBox="0 0 24 24">
          <path
            d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"></path>
        </svg>
        <h3 class="placeholder-title">
          {{ state.placeholderTitle }}
        </h3>
        <p class="placeholder-desc">该模块正在开发中，敬请期待</p>
      </div>
    </main>
  </div>
</template>
<script lang="ts">
  // @ts-nocheck
  import { defineComponent, reactive } from 'vue';
  import {
    ElMenu,
    ElMenuItem,
    ElSubMenu,
    ElButton,
    ElTable,
    ElTableColumn,
    ElTag,
    ElProgress
  } from 'element-plus';
  import { XChart, echarts } from '@vtj/charts';
  import { mock } from 'mockjs';
  import TestTaskPanel from './1kdq1go0.vue';
  import { useProvider } from '@vtj/renderer';
  export default defineComponent({
    name: 'BenchmarkDashboard',
    components: {
      ElMenu,
      ElMenuItem,
      ElSubMenu,
      ElButton,
      TestTaskPanel,
      XChart,
      ElTable,
      ElTableColumn,
      ElTag,
      ElProgress
    },
    setup(props) {
      const provider = useProvider({ id: '1kdp1nlu', version: '1780026319042' });
      const state = reactive({ activeMenu: 'dashboard' });
      return { state, props, provider, echarts, mock };
    },
    methods: {
      generateMockData() {
        const now = new Date();
        const times = Array.from({ length: 10 }, (_, i) => {
          const t = new Date(now - (9 - i) * 30 * 1000);
          return t.toLocaleTimeString('zh-CN', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
          });
        });
        const primary = '#15803d';
        this.state.rpsOption = {
          tooltip: { trigger: 'axis' },
          legend: { data: ['总请求/秒', '失败请求/秒'], right: 0 },
          xAxis: { type: 'category', data: times, axisLabel: { fontSize: 10 } },
          yAxis: { type: 'value', name: '请求数' },
          series: [
            {
              name: '总请求/秒',
              type: 'line',
              data: [320, 332, 301, 334, 390, 330, 320, 310, 340, 342],
              smooth: true,
              lineStyle: { color: primary, width: 2 },
              symbol: 'none'
            },
            {
              name: '失败请求/秒',
              type: 'line',
              data: [2, 5, 3, 4, 8, 6, 3, 2, 1, 3],
              smooth: true,
              lineStyle: { color: '#F56C6C', width: 2 },
              symbol: 'none'
            }
          ]
        };
        this.state.responseTimeOption = {
          tooltip: { trigger: 'axis' },
          legend: { data: ['P50', 'P95'], right: 0 },
          xAxis: { type: 'category', data: times, axisLabel: { fontSize: 10 } },
          yAxis: { type: 'value', name: 'ms', min: 0, max: 600 },
          series: [
            {
              name: 'P50',
              type: 'line',
              data: [88, 92, 85, 95, 102, 98, 90, 86, 91, 95],
              smooth: true,
              lineStyle: { color: '#67C23A', width: 2 },
              symbol: 'none'
            },
            {
              name: 'P95',
              type: 'line',
              data: [150, 162, 145, 168, 178, 165, 155, 148, 156, 160],
              smooth: true,
              lineStyle: { color: '#E6A23C', width: 2 },
              symbol: 'none'
            },
            {
              name: '警戒线',
              type: 'line',
              data: Array(10).fill(400),
              lineStyle: { color: '#F56C6C', width: 1, type: 'dashed' },
              symbol: 'none',
              silent: true
            }
          ]
        };
        this.state.activeUsersOption = {
          tooltip: { trigger: 'axis' },
          xAxis: { type: 'category', data: times, axisLabel: { fontSize: 10 } },
          yAxis: { type: 'value', name: '用户数' },
          series: [
            {
              name: '活跃用户数',
              type: 'line',
              data: [38, 42, 40, 45, 50, 48, 43, 41, 44, 45],
              smooth: true,
              lineStyle: { color: primary, width: 2 },
              symbol: 'circle',
              symbolSize: 4,
              areaStyle: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                  { offset: 0, color: primary + '4D' },
                  { offset: 1, color: primary + '0D' }
                ])
              },
              markPoint: {
                data: [
                  {
                    type: 'max',
                    name: '峰值',
                    symbolSize: 50,
                    label: { formatter: '峰值 50\n08:45:30', fontSize: 10 }
                  }
                ]
              }
            }
          ]
        };
        this.state.apiStats = mock({
          'list|3': [
            {
              'type|1': ['GET', 'POST', 'PUT'],
              'name|1': ['/api/users', '/api/orders', '/api/products'],
              'requests|1000-9999': 1,
              'fails|0-10': 1,
              'median|50-200': 1,
              'p95|100-600': 1,
              'p99|200-800': 1,
              'avg|80-300': 1,
              'min|10-100': 1,
              'max|300-900': 1,
              'avgSize|200-2000': 1,
              'currentRps|20-50': 1,
              'currentFails|0-5': 1
            }
          ]
        }).list;
        this.state.failDetails = mock({
          'list|3': [
            {
              'failCount|1-5': 1,
              'method|1': ['GET', 'POST'],
              'apiName|1': ['/api/users', '/api/orders'],
              errorInfo: 'Connection timeout on attempt #1',
              firstSeen: '2025-01-15 14:23:10',
              lastSeen: '2025-01-15 14:28:45'
            }
          ]
        }).list;
        this.state.exceptionStats = mock({
          'list|3': [
            {
              'count|1-10': 1,
              exceptionInfo: 'java.net.SocketTimeoutException: Read timed out',
              'stackSummary|1': [
                'at com.example.api.HttpClient.execute...',
                'at com.example.service.OrderService.getOrder...',
                'at org.apache.tomcat.util.net.SocketProcessor...'
              ]
            }
          ]
        }).list;
        this.state.recentLogs = [
          { level: 'info', msg: '任务 #1024 完成，RPS 342，成功率 99.77%' },
          { level: 'warning', msg: 'P95 响应时间 156ms，接近阈值 200ms' },
          { level: 'error', msg: '接口 /api/orders 返回 502，已重试 2 次' }
        ];
      },
      handleMenuSelect(index) {
        this.state.activeMenu = index;
        const titles = {
          task: '测试任务',
          report: '测试报告',
          dashboard: '仪表盘',
          script: '脚本库',
          strategy: '策略库'
        };
        this.state.placeholderTitle = titles[index] || '未知模块';
      }
    },
    created() {
      this.generateMockData();
      this.state.placeholderTitle = '仪表盘';
    }
  })
</script>
<style lang="css" scoped>
  :root {
    --theme-color: #15803d;
    --glass-bg: rgba(255, 255, 255, 0.65);
    --glass-border: rgba(21, 128, 61, 0.12);
    --glass-shadow: 0 8px 32px rgba(0, 0, 0, 0.06);
    --glass-blur: 12px;
  }
  .dashboard-app {
    min-height: 100vh;
    background: linear-gradient(135deg, #e8f5e9 0%, #f1f8e9 50%, #e0f2f1 100%);
    font-family:
      -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue',
      Arial, sans-serif;
  }
  .glass-card,
  .glass-header {
    background: var(--glass-bg);
    backdrop-filter: blur(var(--glass-blur));
    -webkit-backdrop-filter: blur(var(--glass-blur));
    border: 1px solid var(--glass-border);
    box-shadow: var(--glass-shadow);
    border-radius: 12px;
  }
  .glass-header {
    position: sticky;
    top: 0;
    z-index: 100;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 24px;
    height: 64px;
    margin-bottom: 24px;
    border-radius: 0;
    border-bottom: 1px solid var(--glass-border);
  }
  .header-left {
    display: flex;
    align-items: center;
    gap: 40px;
  }
  .logo-area {
    display: flex;
    align-items: center;
    gap: 10px;
  }
  .logo-text {
    font-size: 18px;
    font-weight: 700;
    color: var(--theme-color);
  }
  .nav-menu {
    border-bottom: none !important;
    height: 64px;
  }
  .nav-menu .el-menu-item,
  .nav-menu .el-sub-menu__title {
    height: 64px;
    line-height: 64px;
    font-size: 14px;
    font-weight: 500;
    color: #374151;
    border-bottom: 3px solid transparent !important;
    transition:
      color 0.2s,
      border-color 0.2s;
  }
  .nav-menu .el-menu-item.is-active,
  .nav-menu .el-sub-menu.is-active .el-sub-menu__title {
    color: var(--theme-color) !important;
    border-bottom-color: var(--theme-color) !important;
    background: transparent !important;
  }
  .nav-menu .el-menu-item:hover,
  .nav-menu .el-sub-menu__title:hover {
    background: rgba(21, 128, 61, 0.06) !important;
    color: var(--theme-color) !important;
  }
  .header-right {
    display: flex;
    align-items: center;
    gap: 20px;
  }
  .status-badge {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 4px 12px;
    background: rgba(21, 128, 61, 0.1);
    border-radius: 20px;
  }
  .status-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background-color: #67c23a;
    display: inline-block;
  }
  .status-label {
    font-size: 13px;
    color: var(--theme-color);
    font-weight: 500;
  }
  .stop-btn {
    border-radius: 20px;
  }
  .main-content {
    padding: 0 24px 24px;
    max-width: 1440px;
    margin: 0 auto;
  }
  .kpi-row {
    display: flex;
    gap: 16px;
    margin-bottom: 24px;
  }
  .kpi-card {
    flex: 1;
    padding: 16px 20px;
    transition:
      transform 0.2s,
      box-shadow 0.2s;
  }
  .kpi-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 12px 40px rgba(0, 0, 0, 0.08);
  }
  .kpi-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 8px;
  }
  .kpi-label {
    font-size: 13px;
    color: #6b7280;
    font-weight: 500;
  }
  .kpi-trend {
    font-size: 12px;
    font-weight: 500;
  }
  .kpi-trend.up {
    color: var(--theme-color);
  }
  .kpi-trend.down {
    color: #f56c6c;
  }
  .kpi-value {
    font-size: 28px;
    font-weight: 700;
    color: #1f2937;
    line-height: 1.2;
    margin-bottom: 4px;
  }
  .kpi-value.error {
    color: #f56c6c;
  }
  .kpi-sub {
    font-size: 13px;
    color: #9ca3af;
  }
  .highlight {
    color: var(--theme-color);
    font-weight: 600;
  }
  .chart-section {
    padding: 16px;
    margin-bottom: 20px;
  }
  .chart-title {
    font-size: 14px;
    font-weight: 600;
    color: #374151;
    margin: 0 0 12px 0;
  }
  .table-section {
    padding: 16px;
    margin-bottom: 20px;
  }
  .section-title {
    font-size: 14px;
    font-weight: 600;
    color: #374151;
    margin: 0 0 12px 0;
  }
  .api-table .fails-highlight {
    color: #f56c6c;
    font-weight: 600;
  }
  .flame-icon {
    font-size: 14px;
  }
  .p95-highlight {
    color: #e6a23c;
    font-weight: 600;
  }
  .table-row {
    display: flex;
    gap: 20px;
    margin-bottom: 20px;
  }
  .table-half {
    padding: 16px;
  }
  .table-half.left {
    flex: 6;
  }
  .table-half.right {
    flex: 4;
  }
  .toolbar {
    padding: 12px 16px;
    display: flex;
    align-items: center;
    gap: 16px;
  }
  .log-preview {
    display: flex;
    flex-direction: column;
    gap: 4px;
    flex: 1;
  }
  .log-item {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 12px;
  }
  .log-msg {
    color: #6b7280;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 300px;
  }
  .success-rate {
    display: flex;
    align-items: center;
    gap: 8px;
    width: 200px;
  }
  .rate-label {
    font-size: 13px;
    color: #6b7280;
    white-space: nowrap;
  }
  .placeholder-page {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 60vh;
  }
  .placeholder-card {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 16px;
    padding: 48px 64px;
    text-align: center;
  }
  .placeholder-title {
    font-size: 20px;
    font-weight: 600;
    color: #374151;
    margin: 0;
  }
  .placeholder-desc {
    font-size: 14px;
    color: #9ca3af;
    margin: 0;
  }
  .api-table.el-table,
  .el-table {
    background: transparent !important;
  }
  .el-table__header th,
  .el-table__body td {
    background: transparent !important;
  }
  .el-table--border {
    border-color: var(--glass-border) !important;
  }
  .el-table--border th,
  .el-table--border td {
    border-color: var(--glass-border) !important;
  }
</style>
