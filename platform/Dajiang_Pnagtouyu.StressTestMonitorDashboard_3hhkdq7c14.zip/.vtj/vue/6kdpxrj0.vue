<template>
  <div class="test-task-app">
    <div class="toolbar glass-card">
      <div class="toolbar-left">
        <ElInput
          v-model="state.taskName"
          size="default"
          class="task-name-input"
          placeholder="任务名称"></ElInput>
      </div>
      <div class="toolbar-right">
        <ElButton size="default" class="btn-save"> 保存草稿</ElButton>
        <ElButton size="default" type="primary" class="btn-execute">
          立即执行</ElButton
        >
      </div>
    </div>
    <div class="main-content">
      <div class="section glass-card section-scenario">
        <div class="section-header">
          <h3 class="section-title">选择测试场景</h3>
          <span class="section-tip"> 支持多选，可通过 @标签 批量选择</span>
        </div>
        <div class="scenario-toolbar">
          <ElInput
            v-model="state.scenarioSearch"
            size="small"
            class="search-input"
            placeholder="🔍 按场景名称搜索"></ElInput>
          <ElSelect
            v-model="state.selectedTags"
            size="small"
            class="tag-select"
            multiple=""
            placeholder="按标签选择">
            <ElOption
              v-for="(tag, index) in state.allTags"
              :key="tag"
              :label="tag"
              :value="tag"></ElOption
          ></ElSelect>
          <div class="selected-tags">
            <span
              v-for="(tag, idx) in state.selectedTags"
              :key="idx"
              class="tag-badge">
              <span>
                <span> #</span>
                <span> {{ tag }}</span>
                <span> </span
              ></span>
              <ElIcon class="tag-remove" @click="removeTag(tag)">
                <Close></Close></ElIcon
            ></span>
          </div>
        </div>
        <div
          v-for="(group, index) in state.filteredGroups"
          :key="group.name"
          class="scenario-group">
          <div class="group-name">
            <span>
              <span> {{ group.name }}</span>
              <span> (</span>
              <span> {{ group.items.length }}</span>
              <span> 个场景)</span></span
            >
          </div>
          <div
            v-for="(item, index) in group.items"
            :key="item.name"
            class="scenario-item">
            <ElCheckbox v-model="item.checked" size="default"></ElCheckbox>
            <span class="scenario-name"> {{ item.name }}</span>
            <span class="scenario-tags">
              <span
                v-for="(tag, index) in item.tags"
                :key="tag"
                class="tag-dot span_31mkdpyp8k"
                :style="{ backgroundColor: tagColors[tag] || '#999' }"></span
            ></span>
            <span
              :class="
                Object.assign(
                  { 'scenario-rate': true },
                  { 'rate-warn': item.successRate < 99 }
                )
              ">
              <span>
                <span> {{ item.successRate }}</span>
                <span> %</span></span
              ></span
            >
          </div>
        </div>
      </div>
      <div class="section glass-card section-strategy">
        <div class="section-header">
          <h3 class="section-title">测试策略</h3>
          <ElLink type="primary" class="manage-link"> 管理策略库</ElLink>
        </div>
        <div class="strategy-templates">
          <span
            v-for="(tpl, index) in state.strategyTemplates"
            :key="tpl"
            :class="
              Object.assign(
                { 'tpl-btn': true },
                { active: state.activeStrategy === tpl }
              )
            "
            @click="selectStrategy(tpl)">
            {{ tpl }}</span
          >
        </div>
        <div class="preview-chart">
          <XChart
            width="100%"
            height="160px"
            :option="state.strategyOption"></XChart>
        </div>
        <div class="params-grid">
          <div
            v-for="(param, idx) in state.currentParams"
            :key="idx"
            class="param-item">
            <span class="param-label">
              <span>
                <span> {{ param.label }}</span>
                <span> :</span></span
              ></span
            >
            <ElInputNumber
              v-model="param.value"
              :max="param.max"
              :min="param.min"
              size="small"
              class="param-input"></ElInputNumber>
            <span v-if="param.unit" class="param-unit"> {{ param.unit }}</span>
          </div>
        </div>
      </div>
      <div class="section glass-card section-schedule">
        <div class="section-header">
          <h3 class="section-title">执行时间设置</h3>
        </div>
        <div class="schedule-form">
          <div class="schedule-row">
            <span class="label"> 执行方式：</span>
            <ElRadioGroup v-model="state.executeMode" size="default">
              <ElRadio value="immediate"> 立即执行</ElRadio>
              <ElRadio value="scheduled"> 定时执行</ElRadio></ElRadioGroup
            >
          </div>
          <div v-if="state.executeMode === 'scheduled'" class="schedule-row">
            <span class="label"> 执行时间：</span>
            <ElDatePicker
              v-model="state.scheduledTime"
              size="default"
              type="datetime"
              class="date-picker"
              placeholder="选择日期时间"></ElDatePicker>
          </div>
          <div class="schedule-row">
            <span class="label"> 执行时长：</span>
            <ElInputNumber
              v-model="state.durationMinutes"
              :max="999"
              :min="1"
              size="small"
              class="duration-input"></ElInputNumber>
            <span class="unit"> 分钟</span>
            <ElCheckbox
              v-model="state.runUntilStop"
              size="default"
              class="until-stop">
              持续运行直到手动停止</ElCheckbox
            >
          </div>
        </div>
      </div>
      <div class="section glass-card section-advanced">
        <ElCollapse v-model="state.advancedOpen" accordion="">
          <ElCollapseItem name="advanced" title="高级选项">
            <div class="adv-block">
              <h4 class="adv-title">思考时间设置</h4>
              <ElRadioGroup
                v-model="state.thinkMode"
                size="small"
                class="think-mode">
                <ElRadio value="none"> 无等待</ElRadio>
                <ElRadio value="fixed"> 固定等待</ElRadio>
                <ElRadio value="random"> 随机等待</ElRadio></ElRadioGroup
              >
              <div v-if="state.thinkMode === 'fixed'" class="think-params">
                <span class="label"> 固定等待：</span>
                <ElInputNumber
                  v-model="state.fixedWait"
                  :min="0.1"
                  size="small"
                  :step="0.1"></ElInputNumber>
                <span class="unit"> 秒</span>
              </div>
              <div v-if="state.thinkMode === 'random'" class="think-params">
                <span class="label"> 随机等待范围：</span>
                <ElInputNumber
                  v-model="state.randomWaitMin"
                  :min="0.1"
                  size="small"
                  :step="0.1"></ElInputNumber>
                <span class="separator"> -</span>
                <ElInputNumber
                  v-model="state.randomWaitMax"
                  :min="0.1"
                  size="small"
                  :step="0.1"></ElInputNumber>
                <span class="unit"> 秒</span>
              </div>
            </div>
            <div class="adv-block">
              <h4 class="adv-title">数据参数化</h4>
              <ElCheckbox v-model="state.enableCsv" size="default">
                启用 CSV 数据文件</ElCheckbox
              >
              <div v-if="state.enableCsv" class="csv-config">
                <span class="label"> 文件路径：</span>
                <ElInput
                  v-model="state.csvPath"
                  size="small"
                  class="csv-path"></ElInput>
                <ElButton icon="FolderOpened" size="small"> 📂</ElButton>
              </div>
              <div v-if="state.enableCsv" class="csv-config">
                <span class="label"> 数据分配：</span>
                <ElRadioGroup v-model="state.dataAlloc" size="small">
                  <ElRadio value="sequential"> 顺序读取</ElRadio>
                  <ElRadio value="loop"> 循环读取</ElRadio>
                  <ElRadio value="random"> 随机读取</ElRadio></ElRadioGroup
                >
              </div>
              <ElCheckbox v-model="state.enableDynamicData" size="default">
                动态生成数据</ElCheckbox
              >
            </div>
            <div class="adv-block">
              <h4 class="adv-title">分布式执行</h4>
              <ElCheckbox v-model="state.enableDistributed" size="default">
                启用分布式模式</ElCheckbox
              >
              <div v-if="state.enableDistributed" class="dist-config">
                <div class="dist-row">
                  <span class="label"> Worker 节点数：</span>
                  <ElInputNumber
                    v-model="state.workerCount"
                    :min="1"
                    size="small"></ElInputNumber>
                </div>
                <div class="dist-row">
                  <span class="label"> Master 地址：</span>
                  <ElInput
                    v-model="state.masterUrl"
                    size="small"
                    class="master-input"></ElInput>
                </div>
                <div class="dist-row">
                  <span class="label"> 期望 Worker 数：</span>
                  <ElInputNumber
                    v-model="state.expectedWorkers"
                    :min="1"
                    size="small"></ElInputNumber>
                </div>
              </div>
            </div>
            <div class="adv-block">
              <h4 class="adv-title">结果输出配置</h4>
              <ElCheckbox v-model="state.autoSaveReport" size="default">
                自动保存测试报告</ElCheckbox
              >
              <ElCheckbox v-model="state.exportCsv" size="default">
                输出 CSV 统计数据</ElCheckbox
              >
              <div v-if="state.exportCsv" class="output-path">
                <span class="label"> 输出路径：</span>
                <ElInput
                  v-model="state.outputPath"
                  size="small"
                  class="output-input"></ElInput>
                <ElButton icon="FolderOpened" size="small"> 📂</ElButton>
              </div>
              <ElCheckbox v-model="state.enableWebSocket" size="default">
                实时推送数据到 WebSocket</ElCheckbox
              >
              <ElCheckbox v-model="state.enablePrometheus" size="default">
                导出 Prometheus 格式</ElCheckbox
              >
            </div></ElCollapseItem
          ></ElCollapse
        >
      </div>
    </div>
    <div class="bottom-bar">
      <div class="bottom-summary">
        <span
          v-for="(item, idx) in state.summaryItems"
          :key="idx"
          class="summary-item">
          <span class="summary-label">
            <span>
              <span> {{ item.label }}</span>
              <span> :</span></span
            ></span
          >
          <span class="summary-value"> {{ item.value }}</span></span
        >
      </div>
      <div class="bottom-actions">
        <ElButton size="small" class="btn-save"> 保存草稿</ElButton>
        <ElButton size="small" type="primary" class="btn-execute">
          立即执行</ElButton
        >
      </div>
    </div>
  </div>
</template>
<script lang="ts">
  // @ts-nocheck
  import { defineComponent, reactive } from 'vue';
  import {
    ElInput,
    ElButton,
    ElSelect,
    ElOption,
    ElCheckbox,
    ElLink,
    ElInputNumber,
    ElRadioGroup,
    ElRadio,
    ElDatePicker,
    ElCollapse,
    ElCollapseItem
  } from 'element-plus';
  import { Close } from '@vtj/icons';
  import { XChart } from '@vtj/charts';
  import { useProvider } from '@vtj/renderer';
  export default defineComponent({
    name: 'TestTask',
    components: {
      ElInput,
      ElButton,
      ElSelect,
      ElOption,
      Close,
      ElCheckbox,
      ElLink,
      XChart,
      ElInputNumber,
      ElRadioGroup,
      ElRadio,
      ElDatePicker,
      ElCollapse,
      ElCollapseItem
    },
    setup(props) {
      const provider = useProvider({ id: '6kdpxrj0', version: '1780026116983' });
      const state = reactive({});
      return { state, props, provider };
    },
    computed: {
      currentParams() {
        return this.state.strategyParams[this.state.activeStrategy] || [];
      },
      filteredGroups() {
        const search = (this.state.scenarioSearch || '').toLowerCase();
        return this.state.scenarioGroups
          .map((group) => {
            let items = group.items;
            if (search) {
              items = items.filter((item) =>
                item.name.toLowerCase().includes(search)
              );
            }
            if (this.state.selectedTags && this.state.selectedTags.length > 0) {
              items = items.filter((item) =>
                item.tags.some((t) => this.state.selectedTags.includes(t))
              );
            }
            return { ...group, items };
          })
          .filter((g) => g.items.length > 0);
      }
    },
    methods: {
      initState() {
        this.state.taskName = '未命名任务_20260129';
        this.state.scenarioSearch = '';
        this.state.selectedTags = [];
        this.state.allTags = ['login', 'user', 'smoke', 'order', 'p0', 'p1'];
        this.state.tagColors = {
          login: '#3B82F6',
          user: '#10B981',
          smoke: '#F59E0B',
          order: '#8B5CF6',
          p0: '#EF4444',
          p1: '#F97316'
        };
        this.state.scenarioGroups = [
          {
            name: '用户模块',
            items: [
              {
                name: '登录登出流程',
                tags: ['login', 'smoke'],
                successRate: 99.2,
                checked: true
              },
              {
                name: '用户信息查询',
                tags: ['user'],
                successRate: 100,
                checked: true
              },
              {
                name: '修改密码流程',
                tags: ['user', 'smoke'],
                successRate: 98.5,
                checked: false
              }
            ]
          },
          {
            name: '订单模块',
            items: [
              {
                name: '创建订单流程',
                tags: ['order', 'p0'],
                successRate: 97.8,
                checked: true
              },
              {
                name: '查询订单列表',
                tags: ['order'],
                successRate: 100,
                checked: false
              },
              {
                name: '订单详情查看',
                tags: ['order'],
                successRate: 99.9,
                checked: false
              },
              {
                name: '取消订单流程',
                tags: ['order', 'p1'],
                successRate: 95.2,
                checked: false
              }
            ]
          }
        ];
        this.state.strategyTemplates = [
          '阶梯增长',
          '波浪形',
          '突发峰值',
          '稳定性测试',
          '自定义'
        ];
        this.state.activeStrategy = '阶梯增长';
        this.state.strategyParams = {
          阶梯增长: [
            { label: '起始用户数', value: 0, min: 0, max: 10000, unit: '' },
            { label: '峰值用户数', value: 200, min: 1, max: 100000, unit: '' },
            { label: '爬坡时间', value: 30, min: 1, max: 600, unit: '秒' },
            { label: '每个阶梯时长', value: 60, min: 1, max: 3600, unit: '秒' },
            { label: '孵化率', value: 10, min: 1, max: 1000, unit: 'users/秒' }
          ],
          波浪形: [
            { label: '振幅', value: 100, min: 1, max: 10000, unit: '' },
            { label: '周期', value: 60, min: 1, max: 3600, unit: '秒' },
            { label: '基线', value: 50, min: 0, max: 10000, unit: '' }
          ],
          突发峰值: [
            { label: '基线', value: 50, min: 0, max: 10000, unit: '' },
            { label: '峰值', value: 500, min: 1, max: 100000, unit: '' },
            { label: '峰值时刻', value: 120, min: 1, max: 3600, unit: '秒' }
          ],
          稳定性测试: [
            { label: '恒定用户数', value: 100, min: 1, max: 100000, unit: '' },
            { label: '运行时长', value: 30, min: 1, max: 999, unit: '分钟' }
          ],
          自定义: []
        };
        this.state.executeMode = 'immediate';
        this.state.scheduledTime = null;
        this.state.durationMinutes = 5;
        this.state.runUntilStop = false;
        this.state.advancedOpen = '';
        this.state.thinkMode = 'fixed';
        this.state.fixedWait = 1;
        this.state.randomWaitMin = 0.5;
        this.state.randomWaitMax = 3;
        this.state.enableCsv = false;
        this.state.csvPath = './test_data/users.csv';
        this.state.dataAlloc = 'loop';
        this.state.enableDynamicData = false;
        this.state.enableDistributed = false;
        this.state.workerCount = 3;
        this.state.masterUrl = 'http://localhost:8089';
        this.state.expectedWorkers = 3;
        this.state.autoSaveReport = true;
        this.state.exportCsv = true;
        this.state.outputPath = './reports/';
        this.state.enableWebSocket = false;
        this.state.enablePrometheus = false;
        this.state.summaryItems = [];
      },
      removeTag(tag) {
        this.state.selectedTags = this.state.selectedTags.filter(
          (t) => t !== tag
        );
      },
      updateSummary() {
        const selectedScenarios = [];
        for (const g of this.state.scenarioGroups) {
          for (const item of g.items) {
            if (item.checked) selectedScenarios.push(item.name);
          }
        }
        const tags = [];
        for (const g of this.state.scenarioGroups) {
          for (const item of g.items) {
            if (item.checked) {
              for (const tag of item.tags) {
                if (!tags.includes(tag)) tags.push(tag);
              }
            }
          }
        }
        const paramsList =
          this.state.strategyParams[this.state.activeStrategy] || [];
        const paramDesc = paramsList
          .map((p) => `${p.label} ${p.value}${p.unit}`)
          .join(', ');
        this.state.summaryItems = [
          {
            label: '场景',
            value: `${selectedScenarios.length}个 (${selectedScenarios.join('、')})`
          },
          { label: '标签', value: tags.map((t) => '#' + t).join(' ') },
          { label: '策略', value: `${this.state.activeStrategy} (${paramDesc})` },
          {
            label: '执行',
            value:
              this.state.executeMode === 'immediate'
                ? '立即执行'
                : `定时 ${this.state.scheduledTime}`
          },
          {
            label: '参数化',
            value: this.state.enableCsv ? '已启用CSV' : '未启用'
          },
          {
            label: '分布式',
            value: this.state.enableDistributed
              ? `${this.state.workerCount}个Worker`
              : '未启用'
          }
        ];
      },
      selectStrategy(tpl) {
        this.state.activeStrategy = tpl;
        this.buildStrategyChart();
        this.updateSummary();
      },
      buildStrategyChart() {
        const tpl = this.state.activeStrategy;
        let data = [];
        const steps = 60;
        for (let i = 0; i <= steps; i++) {
          const t = i;
          let v = 0;
          if (tpl === '阶梯增长') {
            const peak = 200;
            const rampSteps = 10;
            const stepSteps = 15;
            if (t < rampSteps) {
              v = (peak / rampSteps) * t;
            } else {
              v = peak;
            }
          } else if (tpl === '波浪形') {
            const amp = 100;
            const baseline = 50;
            v = baseline + amp * Math.sin((t / 20) * Math.PI);
          } else if (tpl === '突发峰值') {
            const baseline = 50;
            const peak = 500;
            if (t < 10) v = baseline;
            else if (t < 25) v = baseline + ((peak - baseline) / 15) * (t - 10);
            else if (t < 35) v = peak;
            else v = baseline;
          } else if (tpl === '稳定性测试') {
            v = 100;
          } else {
            v = 50 + t * 2;
          }
          data.push(v);
        }
        const labels = data.map((_, i) => i * 6 + 's');
        this.state.strategyOption = {
          tooltip: { trigger: 'axis' },
          grid: { left: 40, right: 20, top: 10, bottom: 25 },
          xAxis: { type: 'category', data: labels, show: false },
          yAxis: { type: 'value', show: false },
          series: [
            {
              data,
              type: 'line',
              smooth: true,
              lineStyle: { color: '#3B82F6', width: 2 },
              areaStyle: { color: 'rgba(59,130,246,0.1)' },
              symbol: 'none'
            }
          ]
        };
      }
    },
    created() {
      this.initState();
      this.updateSummary();
      this.buildStrategyChart();
    }
  })
</script>
<style lang="css" scoped>
  /* 全局 */
  .test-task-app {
    min-height: 100vh;
    background-color: #f9fafb;
    font-family:
      -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue',
      Arial, sans-serif;
    padding: 24px;
    max-width: 1200px;
    margin: 0 auto;
    padding-bottom: 80px; /* 底部栏高度 */
  }
  .glass-card {
    background: #fff;
    border: 1px solid #e5e7eb;
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 20px;
    transition: box-shadow 0.2s;
  }
  .glass-card:hover {
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06);
  }
  /* 顶部工具栏 */
  .toolbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 16px 24px;
    margin-bottom: 24px;
    border-radius: 12px;
  }
  .toolbar-left {
    flex: 1;
    max-width: 400px;
  }
  .task-name-input {
    width: 100%;
  }
  .toolbar-right {
    display: flex;
    gap: 12px;
  }
  .btn-save {
    border: 1px solid #d1d5db;
    color: #374151;
  }
  .btn-execute {
    background-color: #3b82f6;
    border-color: #3b82f6;
  }
  /* 区域标题 */
  .section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 16px;
  }
  .section-title {
    font-size: 16px;
    font-weight: 600;
    color: #1f2937;
    margin: 0;
  }
  .section-tip {
    font-size: 12px;
    color: #9ca3af;
    margin-left: 12px;
  }
  /* 场景工具栏 */
  .scenario-toolbar {
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
    align-items: center;
    margin-bottom: 16px;
  }
  .search-input {
    width: 200px;
  }
  .tag-select {
    width: 160px;
  }
  .selected-tags {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
  }
  .tag-badge {
    display: inline-flex;
    align-items: center;
    background: #f3f4f6;
    border-radius: 12px;
    padding: 2px 8px;
    font-size: 12px;
    color: #374151;
  }
  .tag-remove {
    cursor: pointer;
    margin-left: 4px;
    font-size: 12px;
  }
  /* 场景分组 */
  .scenario-group {
    margin-bottom: 16px;
  }
  .group-name {
    font-size: 13px;
    font-weight: 600;
    color: #6b7280;
    margin-bottom: 8px;
    padding-left: 4px;
  }
  .scenario-item {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 4px;
    border-bottom: 1px solid #f3f4f6;
  }
  .scenario-item:last-child {
    border-bottom: none;
  }
  .scenario-name {
    flex: 1;
    font-size: 14px;
    color: #1f2937;
  }
  .scenario-tags {
    display: flex;
    gap: 4px;
  }
  .tag-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    display: inline-block;
  }
  .scenario-rate {
    font-size: 12px;
    color: #6b7280;
    white-space: nowrap;
  }
  .rate-warn {
    color: #ef4444;
  }
  /* 策略模板 */
  .strategy-templates {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    margin-bottom: 16px;
  }
  .tpl-btn {
    padding: 6px 16px;
    border: 1px solid #d1d5db;
    border-radius: 20px;
    font-size: 13px;
    color: #374151;
    cursor: pointer;
    transition: all 0.2s;
  }
  .tpl-btn:hover {
    border-color: #3b82f6;
    color: #3b82f6;
  }
  .tpl-btn.active {
    background-color: #3b82f6;
    color: #fff;
    border-color: #3b82f6;
  }
  .preview-chart {
    margin-bottom: 16px;
  }
  .params-grid {
    display: flex;
    flex-wrap: wrap;
    gap: 16px;
  }
  .param-item {
    display: flex;
    align-items: center;
    gap: 6px;
  }
  .param-label {
    font-size: 13px;
    color: #374151;
    white-space: nowrap;
  }
  .param-input {
    width: 100px;
  }
  .param-unit {
    font-size: 12px;
    color: #9ca3af;
  }
  /* 执行时间 */
  .schedule-form {
    display: flex;
    flex-direction: column;
    gap: 12px;
  }
  .schedule-row {
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 14px;
    color: #374151;
  }
  .schedule-row .label {
    width: 90px;
    text-align: right;
    flex-shrink: 0;
  }
  .date-picker {
    width: 240px;
  }
  .duration-input {
    width: 80px;
  }
  .unit {
    font-size: 13px;
    color: #9ca3af;
  }
  .until-stop {
    margin-left: 12px;
  }
  /* 高级选项 */
  .adv-block {
    margin-bottom: 20px;
    padding: 12px;
    background: #f9fafb;
    border-radius: 8px;
  }
  .adv-title {
    font-size: 14px;
    font-weight: 600;
    color: #374151;
    margin: 0 0 8px 0;
  }
  .think-mode {
    display: flex;
    gap: 12px;
    margin-bottom: 8px;
  }
  .think-params {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-top: 8px;
  }
  .think-params .label {
    font-size: 13px;
    color: #6b7280;
  }
  .separator {
    font-size: 14px;
    color: #9ca3af;
  }
  .csv-config {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-top: 8px;
  }
  .csv-config .label {
    font-size: 13px;
    color: #6b7280;
  }
  .csv-path {
    width: 240px;
  }
  .master-input {
    width: 240px;
  }
  .output-path {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-top: 8px;
  }
  .output-path .label {
    font-size: 13px;
    color: #6b7280;
  }
  .output-input {
    width: 200px;
  }
  .dist-row {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-top: 8px;
  }
  .dist-row .label {
    font-size: 13px;
    color: #6b7280;
    width: 110px;
  }
  /* 底部预览栏 */
  .bottom-bar {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    background: #f3f4f6;
    border-top: 1px solid #e5e7eb;
    padding: 12px 24px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    z-index: 100;
    max-width: 1200px;
    margin: 0 auto;
  }
  .bottom-summary {
    display: flex;
    flex-wrap: wrap;
    gap: 16px;
    flex: 1;
  }
  .summary-item {
    font-size: 12px;
    color: #6b7280;
  }
  .summary-label {
    font-weight: 500;
  }
  .summary-value {
    color: #374151;
    margin-left: 4px;
  }
  .bottom-actions {
    display: flex;
    gap: 8px;
  }
  /* element-plus 覆盖 */
  .el-checkbox {
    margin-right: 0;
  }
  .el-collapse-item__header {
    font-size: 14px;
    font-weight: 500;
  }
  .el-collapse-item__content {
    padding-bottom: 0;
  }
</style>
